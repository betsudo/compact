> Frozen documentation snapshot for the November 13, 2026 book edition. Entries retain their historical source-specific scope. Later receipts can supersede earlier open items.

# Ledger 9 adoption on the Rust AST line

The [integrated local qualification](#integrated-local-qualification-passed)
records the passing macOS arm64 run and the remaining integration gates.
The earlier entries record each migration step at its tested revision.

The local `rust-ast-backend-ledger9` branch starts at `09c75e289`, the published Rust AST line after PR #723. The Ledger 8 line and its qualification receipts remain available for historical compatibility and the pending tuple-spread application review.

This first slice pins the published [Ledger 9.1.0.1 package set](https://github.com/midnightntwrk/midnight-ledger/releases/tag/ledger-9.1.0.1) in the runtime and aligns the core consumers' direct Ledger package pins. The runtime uses the Ledger 9 transaction signature enum, accepts Ledger 9 observation metadata, and uses the ledger's global TTL in the existing Zswap test setup. Observed call preparation preserves the complete installed operation after checking the verifier. The direct fixture path still constructs a verifier-only operation. The proof consumer must check its resolver artifacts against the observed operation.

The runtime parity tests use fresh byte-for-byte TypeScript captures for Counter, Map, Set and List. The Ledger 8 JSON oracles remain intact. The captures use Compact 0.36.0, Compact Runtime 0.21.0 and Onchain Runtime 4.0.1, with the release's bundled ZKIR v3 compiler. The fixtures have no attached keys or IR in the installed operation.

| Fixture | Compact source | Revision |
| --- | --- | --- |
| Counter | `examples/rust_backend/counter.compact` | `09c75e289` |
| Set constructor | `examples/rust_backend/set_oracle.compact` | `09c75e289` |
| Map constructor | `examples/rust_backend/map_oracle.compact` | `09c75e289` |
| List constructor | `examples/rust_backend/list_oracle.compact` | `09c75e289` |
| Set transitions | `examples/rust_backend/set_boolean.compact` | `29ba39d0138ce66293c70d1d0fddb2ca2ed8e7011` |
| Map transitions | `examples/rust_backend/map_boolean_field.compact` | `bd2415e156e0f63189aebba8258aff43eeba6545` |
| List transitions | `examples/rust_backend/list_field.compact` | `09c75e289` |

The Set and Map transition sources retain the export sets of the existing Rust fixtures. Capture them with `compactc --skip-zk` in a directory that resolves the pinned npm packages. Run `runtime-rs/tests/fixtures/capture-ledger9-counter.mjs` or `capture-ledger9-collection.mjs` with the generated contract entry and matching Compact runtime entry. The collection script also takes `initial`, `set`, `map`, or `list`. The tests compare full serialized contract states.

The migration branch is an integration worktree. The active Rust workspace resolves the published Ledger 9 package graph from crates.io. The initial migration retained the v2 producer recipe with ZKIR 2.2.0. The Ledger 9 proof gates below use ZKIR 3.2.0. Use `cargo test -p midnight-compact-runtime --all-features --all-targets --locked` for the Rust runtime.

Port the remaining fixture and proof consumers and pass the required Linux, package and end-to-end gates before switching the distribution default.

The current Scheme frontend can emit Rust IR and ZKIR v3 in the same invocation with `--feature-zkir-v3`. The official Compact 0.36.0 reference emits a newer ZKIR format and has no Rust IR entry point. Check the exact current frontend artifacts against the selected official ZKIR tool before generating keys. Preserve the compiler's source/runtime pairing checks and give the Ledger 9 pair a distinct ABI identity when qualifying generated Rust.

Use the released Ledger 9 transaction and proof APIs as the reference. Keep the observed operation and its installed verifier bound to the resolver artifact. The funded lane needs the released `dust/10/spend` material, which differs from the retained Ledger 8 `dust/9/spend` material. The Dust proof and the Counter's ZKIR v3 proof use different verifier roles.

Local macOS arm64 validation with Rust 1.99 passed all 281 runtime tests and 1,874 backend library tests. Seven backend tests remained ignored. The testkit library also type-checked with its proof feature enabled. The same-source retained Rust AST frontend emitted private IR and ZKIR v3 for the Counter. The bundled official ZKIR tool modeled both exports at automatic k=6. This was a source and model probe, with the Ledger 9 compiler pairing and genuine proof/application still open.

## Local compiler/runtime pairing

The ordinary Rust target selects ZKIR v3 and emits ABI 54 against the exact Ledger 9 runtime dependency matrix. The runtime uses the published `midnight-ledger-v9` crate name, so the existing manifest validator can continue to reject Cargo package aliases and alternate sources. Runtime and generated consumers declare Rust 1.99 for this local qualification. The legacy Ledger 8 functional CLI mode refuses on the migration branch. The historical fixtures retain their Ledger 8 ABI on the Ledger 8 line.

The standard `compactc --target rust --rust-require-recording --rust-runtime-root … --skip-zk` invocation generated an unedited Counter crate and its ZKIR. The generated crate compiled with the transaction feature. Native execution, the typed observed call, recorded replay, and the independently captured Ledger 9 TypeScript oracle agreed on the selected transition and full state bytes. Native and recorded gas matched. The official ZKIR model tool accepted both retained artifacts at k=6. CLI preflight refused a Ledger 8 source root and preserved existing output. Local Rust 1.99 arm64 validation included 30 CLI tests, 21 compatibility tests, and 281 runtime tests.

## Funded Counter qualification

The first standalone proof passed, but the Ledger 9 transaction prover exhausted its skip entries before producing a contract proof. The previous ZKIR v3 emitter grouped multiple expanded ledger operations into one impact. Ledger 9 consumes a skip entry for each transcript operation. The updated emitter keeps those operation boundaries and omits suppressed operations. Counter's three impact instructions match the released Compact 0.36.0 output. The generated artifacts retain this branch's ZKIR 3.0 JSON format.

The rebuilt Scheme frontend generated an unedited Rust Counter crate and its exact ZKIR. The regenerated crate still passed native, recorded and observed execution parity with the independent TypeScript oracle. Released ZKIR 3.2.0 generated fresh k=6 keys and a standalone proof for `increment`. A separate process verified the proof, refused a different circuit's verifier, changed binding and commitment fields, and corrupted proof bytes, then verified the original again.

A separate local transaction used the same exact IR and installed verifier with a fresh transaction-bound v3 proof. It proved one Dust spend using the released Ledger 9 `dust/10/spend` material, passed default strict validation, and applied the expected generated Rust state transition. The installed operation stayed intact. Replaying the verified transaction returned `IntentAlreadyExists` with byte-identical whole-ledger state. This qualification used Rust 1.99 on macOS arm64, with locally funded test state.

Next, migrate the maintained proof gate and TypeScript/Nix package pairing, then regenerate the affected workspace consumers. Keep historical v2 proof/source bindings and Ledger 8 fixtures available on their original line. A Ledger 9 check must bind its own generated Rust, ZKIR v3, keys and released package graph.

## Rust 1.99 toolchain

The workspace and Nix-packaged Rust CLI select Rust 1.99.0. Nix checks the official release manifest hash and uses the matching Cargo, compiler and standard library. Linux uses the matching musl standard library and keeps the static linker and ELF checks. The standalone compiler lock is selected from the workspace lock and its registry package identities, checksums and retained edges are audited before a locked build.

## TypeScript package pairing

This branch's synchronous Compact runtime uses minor `0.17.0` and the published `@midnightntwrk/onchain-runtime-v4@4.0.1`. The Nix package consumes the registry artifact from the npm lockfile. Compiler output checks the runtime minor at import. Both cross-version controls refused when swapping generated code and runtime between `0.16.102` and `0.17.0`. The official asynchronous Compact Runtime 0.21.0 remains the independent oracle.

Build `.#compactc` and `.#runtime.package`. Generate Counter with `--target ts --target rust --rust-require-recording --skip-zk`. With the packed runtime and its locked dependencies available to Node, run `runtime-rs/tests/fixtures/capture-ledger9-paired-counter.mjs` on the generated `contract/index.js`. The capture checks the shared Ledger 9 module identity and exact before/after contract bytes against the official oracle. The generated Rust consumer matched those bytes, all four gas fields and the typed return. Its two ZKIR files were byte-identical to the qualified standalone and funded proof inputs.

The native macOS arm64 Nix runtime and compiler packages built, the runtime tests passed, and the compiler suite passed in both existing JavaScript check modes.

## Released ZKIR tool pairing

The packaged native v3 compiler builds the published `midnight-zkir` 3.2.0 crate with a standalone, registry-only Ledger 9 lock on Rust 1.99.0. The JavaScript check harness installs the published ZKIR v3 3.2.0 and ZKIR v2 2.2.0 WASM packages from its lockfile. The existing v2 native producer and historical receipts remain available. Rust and both-target invocations report the v3 package version.

The v3 emitter now uses the released point and scalar conversion instructions. It lowers each hash to a typed Bytes32 result and splits the digest back into Compact's high-byte-first field representation. This keeps the typed Compact value, its hash alignment, and the public transcript ordering consistent. The v2 emitter retains its original snapshots and check mode.

On macOS arm64, the compiler suite passed all 3,883 checks, including all 168 v3 snapshots and the JavaScript checks in both ZKIR modes. The portable compiler reproduced the exact Counter and guarded Counter ZKIR and Rust libraries used in proof qualification. The packaged native CLI reproduced the straight-line Counter's binary IR, proving key and verifier key byte-for-byte. The published v3 WASM package agreed with the native binary IR for both the straight-line and guarded Counter. Both guarded Counter branches passed with a fresh transaction-bound v3 proof and real Dust funding. Each had 20 active transcript operations, one proved no-op, matching generated TypeScript state and typed return, and byte-identical ledger state after exact replay refusal. The reset branch starts and ends with the same contract value while the ledger records fees and replay protection. Both Linux musl tool derivations were evaluated locally.

The maintained v3 proof gate still needs to bind its producer, exact generated artifacts, separate verifier and transaction application. Current fixture freshness and the accepted functional SDK routes still need regeneration and qualification on Ledger 9.

## Earlier Compact Ledger 9 branch

The local `ledger9-rustbackend` ref at `6f4e5948f` records the Rust backend port and constructor rejection corpus. The retained `origin/ledger9-rustbackend` ref at `fc879310b` also records the TypeScript fixture update for the options-object `createCircuitContext` API and an independent Rust toolchain pin. Its runtime still uses the Ledger 9 RC3 Git graph and Rust 1.95.0. Use its negative cases and fixture recipes as references when auditing current gates. Keep this migration on the Rust AST line with released packages and Rust 1.99.0.

## Nested Jubjub ledger values

The read-only fixture audit found five v3 compiler crashes in DID, its digest reducer, a Jubjub Cell, a nested enum and a nested point map. This branch adapts the physical ledger encoding from the earlier Compact fix at `ee345ee15` to the current ZKIR v3 emitter. It writes each Jubjub point as two field coordinates and binds each public read as a typed point. The default path encodes the identity point as `(0, 1)`. The regression runs the generated TypeScript through round trip, both guarded read branches and reset with the v3 preimage checker. The v2 checker covers round trip and guarded reads. A separate probe reproduced the existing v2 default-reset transcript mismatch.

Mixed native values with a zero-width unsigned field require a separate layout fix. The current compiler rejects the ambiguous alignment at the source. Generic native-type hash inputs and Merkle path recomputation also remain separate from the repaired ledger operand and leaf encoding.

## Ordinary Rust fixtures

The first regeneration covers Counter, Boolean Cell, Jubjub Cell, Map and List. The current compiler emits ABI 54 in each library. The isolated macOS arm64 workspace used the published Ledger 9 graph and passed all 20 existing tests with all features and targets. The compiler regenerated these libraries from their Compact sources with Rust 1.99 formatting. The fixture test sources and coordinate oracle remain the same.

All 255 ordinary fixture libraries have been regenerated. The 202 fixture manifests with direct Ledger 8 Git dev dependencies now use the runtime's exact published crate pins. The resolved macOS arm64 workspace contains one `midnight-ledger-v9` 1.0.1, Onchain State/Runtime/VM 4.0.1, Storage 3.0.0, Serialize 1.2.1 and Zswap 9.0.1. Both published ZKIR majors remain available for their distinct check modes. The registry records the 66 changed manifests used by generated-consumer build bindings. The Ledger 8 transition tests reconstruct and verify their historical manifest bytes against the recorded hashes.

## Functional Ledger 9 entry

`compactc --target rust --rust-functional-ledger9` emits source-bound checked programs labelled `9.1.0.1` and enables the generated crate's functional runtime feature. The emitted compatibility record and ABI 54 identify the paired source runtime. The experimental typed adapter API retains its existing names. The Ledger 8 CLI flag still refuses before publication.

The Nix-built Rust CLI paired with the same Scheme frontend reproduced the generated Counter Rust library, checked programs, TypeScript and ZKIR byte-for-byte. Its functional native and recorded results matched ordinary Rust state and gas. Preparing the functional trace against the observed contract retained the same installed operation and produced the same call prototype as the ordinary recording. The generated TypeScript matched the independent Ledger 9 oracle and the applied contract's serialized state.

On macOS arm64, the functional recording generated a fresh ZKIR v3 proof and passed verification in a separate process, including the wrong-key, wrong-binding, wrong-commitment and corrupted-proof controls. A separately proved transaction spent one Dust input, applied under default strict validation, and refused replay with `IntentAlreadyExists` and byte-identical ledger state. This local gate covers Counter. The remaining maintained proof consumers and required Linux integration gates still need migration and qualification.

The source registry now uses the Ledger 9 flag for its 29 functional fixtures. Their complete checked-program sidecars and formatted Rust libraries were regenerated from the registered sources. The fixture producer completed all 284 ordinary and functional registrations with no generation failures.

The CI static-fixture resolver now authenticates the Ledger 9 registry archive against its pinned Cargo checksum and compares the extracted manifest, Dust IR, verifier and digest declarations against that archive. The real resolver passed against the locked macOS arm64 workspace metadata. The separately distributed Dust prover stays subject to the upstream digest check.

## Workspace checks and parity captures

On macOS arm64, Rust 1.99 type-checked the locked workspace with all features and targets. Ledger 9 fixture setup uses the two-argument contract operation constructor, the transaction signature enum, and the upstream global TTL for Zswap. The synthetic v2 IR uses the published v2 minor-version type. The packaged compiler's fixture freshness check passed all 284 registrations.

Vector and tuple cells, effectful returns, shielded merge, and transient receive and send use fresh Ledger 9 TypeScript captures generated by the paired compiler with `--target ts --feature-zkir-v3 --skip-zk` and Compact Runtime 0.17.0 with Onchain Runtime 4.0.1. The existing capture scripts produce the full state and applicable transcript and gas records. The Ledger 8 capture files are retained. The focused arm64 run passed 44 tests across these four fixtures, the historical ABI boundary control, and the testkit.

The bounded Uint and Bug 11 cases also pass against freshly generated Ledger 9
TypeScript captures. Both keep their exact state, gas, transcript and replay
checks. The initial workspace run, built before these capture updates, reported
3,109 passes, 322 failures and seven ignored tests. The failures comprise 309
state-byte or state-tag mismatches, 12 reviewed-capture provenance mismatches,
and one witness Cell gas-limit assertion. Each current capture still needs
independent regeneration and the gas-limit case needs a separate diagnosis.

## Maintained witnessed SDK proof

The witnessed Field Cell consumer uses the published ZKIR v3 compiler and
the Ledger 9 package graph. The selected circuit requires k7 and 68 rows.
The proof material resolver verifies the published Dust and Zswap files using
the upstream decoder for their tagged v2 IR. The v3 contract IR and the v2
built-in IR use their respective published decoders.

A local macOS arm64 probe produced a fresh 3,824-byte standalone v3 proof and
verified it in a separate process. Its independently proved transaction used
one Dust spend, passed default-strict validation, applied the expected Field
Cell value 42, and refused replay with byte-identical full ledger state. The
probe also passed the preparation, input, output, binding, proof-corruption,
and private witness refusal controls. The complete isolated source-SDK gate subsequently passed all 30 steps on
macOS arm64 at `4028a7b4b`. It used the original packaged compiler with no
runtime or Scheme override, ran three positive ContractLab tests and the three
typed compile-fail controls, and linted the consumer, bundled SDK and copied
testkit. It generated fresh k7 keys and proved, separately verified, and
strictly applied the selected call with a distinct funded transaction proof.
The remaining required proof workflows and native Linux checks are open.

## Expanded TypeScript parity cohort

The next 18 fixture packages compare fresh Ledger 9 TypeScript captures for
collections, hashes, arithmetic, control flow and witnessed state transitions.
The Map, nested Map, Set and witness recording cases use a separate nine-case
capture. The original nine-case capture and capture script remain bound to
their reviewed Ledger 8 versions. The witnessed Cell state comparison includes
the generated `write_offset` entry. Its gas-limit test uses a zero minimum
deletion credit, as required by the Ledger 9 cost-bound comparison, and retains
both the aggregate-meter assertion and the insufficient-read-budget refusal.

The locked macOS arm64 retest passed all 57 tests across these 18 packages,
with all features and targets enabled. The broader workspace behavioral suite
still needs fresh captures and the remaining provenance and proof migrations.

## Original DID lifecycle

The original two-file DID source closure regenerated byte-identical raw Rust IR,
source origins, capabilities, all twelve checked programs and the formatted
Rust library. The fresh Ledger 9 TypeScript capture retains all twelve DID
cases. Compared with the historical capture, the changed fields are serialized
contract states. The seven Rust lifecycle tests pass across the ordinary and
functional routes. The original Ledger 8 capture remains available.

The complete native lifecycle gate passed on macOS arm64 at `c2c73023f`.
It checked all twelve live DID observations, three typed misuse controls and
Clippy. The two positive cases ran across four Rust routes, and the ten failure
cases exercised all four routes.

The v3 emitter now bounds each active multiplication operand by the Jubjub
scalar order and converts it to the typed scalar consumed by ZKIR. An inactive
guard selects zero before the check. The explicit reduction builtin encodes its
result back into a Compact Field so it can still participate in Field arithmetic.
The released v3 tool models the unchanged DID `deactivate` source at k11 and
1,918 rows. The DID k11 recipe and the small-fixture limit stay in force.

Generated Rust retains canonical scalar rejection. The published Ledger 9
TypeScript provider reduces a raw scalar at or above the order. ZKIR refuses
the resulting noncanonical active call preimage. The v3 checks also cover an
inactive noncanonical operand and explicit Field reduction. The branch's
TypeScript runtime now enforces the same canonical bound before calling the
published provider. See the fixture validation below.

Both original DID deactivation cases passed the maintained Ledger 9 proof
gate on macOS arm64 at `65568d356`. The cases retain the 200 and zero timestamp
witnesses and the complete original source, Rust IR and twelve checked programs.
Each case generated fresh k11 keys, a 4,208-byte standalone proof and a distinct
v3 proof in a funded transaction with one proved Dust spend. A separate process
verified the retained standalone proof and rejected corrupted bytes. The
changed binding and changed version input controls refused. Both transactions
applied with default strictness, the expected installed operation and state
were preserved, and exact replay returned `IntentAlreadyExists` with identical
serialized ledger bytes. The gate checks the modeled geometry and published
material before key generation. The workflow prepares k11 for this DID lane.

The full compiler suite passed 3,887 checks, including all 168 ZKIR v3
snapshots and the JavaScript suites in both ZKIR modes. All 284 Rust fixture
registrations were fresh. The locked workspace type-check passed with all
features and targets. The original DID native lifecycle and the 30-step
witnessed SDK gate also passed with the corrected packaged compiler.
Both Ledger 9 proof gates refuse a configured external proof server.

The reviewed original DID tests now use fresh Ledger 9 captures. The unchanged
capture producers ran with Compact Runtime 0.17.0 and Onchain Runtime 4.0.1.
The complete generated DID Rust library matched the checked-in library after
formatting. All 203 lifecycle steps and 24 composition rows retained their
case identities and changed only serialized contract-state fields. All 102
pure cases matched. The DID and reduced crypto composition suites passed all
48 tests on macOS arm64 with Rust 1.99, including full state and transcript
comparisons and the retained and current identity checks.

The [capture binding](../../../tests-rust-backend/did-adoption/oracle/ledger9/binding.json)
records the paired compiler, runtime package, generated JavaScript, input and
test hashes. The original capture files and review records retain their Ledger
8 identities. To reproduce the Ledger 9 observations, generate both targets
from the unchanged DID source with `--feature-zkir-v3 --rust-require-recording
--skip-zk` and the paired Rust runtime root. Generate the reduced
`unit_composition_crypto.compact` TypeScript target with
`--feature-zkir-v3 --skip-zk`. Run the original DID lifecycle, pure and
composition producers from a staged repository root, with the paired package
at `runtime` and both generated modules resolving that same package. Keep the
producers and case modules at their original repository-relative paths so the
capture can hash its inputs. Only the new Ledger 9 data enters these Rust
conformance tests. The existing Ledger 8 proof inputs stay bound to their
original evidence.

The original Passport fixture also has a
[Ledger 9 binding](../../../tests-rust-backend/vc-passport-adoption/oracle/ledger9/binding.json).
The paired compiler regenerated the complete Rust library and TypeScript
contract from the pinned 17-file source closure. The original TypeScript
producers recaptured all 202 named cases across 75 exports. The data matched
the historical branch captures exactly after comparing each profile label
separately. The Rust fixture tests check the new capture hashes and complete
generated library alongside the two historical TypeScript profiles. The
Passport fixture passed all 20 tests on macOS arm64. The original contract
exports only pure circuits.

The maintained standalone Passport SDK gate passed on macOS arm64 at
`8c69103b3`. It binds the published Ledger 9 registry lock identity and
the resolved Onchain Runtime 4.0.1 JavaScript and WASM. The raw generated
SDK, isolated adoption consumer and documented consumer passed strict
Clippy. The adoption and guide consumers passed 18 Rust methods in total.
All 202 live TypeScript cases matched both the historical upstream capture
and the reviewed Ledger 9 capture. Both correct-type twins compiled, both
typed misuse cases refused at the intended E0308 spans, and a changed
TypeScript expectation failed the actual Rust assertion before the restored
expectation passed. The gate retains the original pure source closure and
the guide's historical lock separately. The gate checks the native Onchain
Runtime, State and VM pins and the actual resolved packages in each consumer.
The separate formatting copy uses a retained configuration.

The original Map size `put` models at k7 and 119 rows with released ZKIR
3.2.0. Fresh Ledger 9 generation matched the complete formatted Rust, linked
IR and all eight checked programs. The maintained generated API gate passed
eight Rust consumer tests, 19 live TypeScript cases, two boundary cases and
four refusals. Both source refusals, the E0308 and E0382 compile failures,
and the changed-TypeScript-result control passed. Both replacement and
insertion passed fresh v3 proving at `fe9e8d22b`. Each case retained a
3,824-byte standalone proof and a distinct 3,824-byte transaction-bound
v3 proof. A separate verifier process accepted both standalone proofs and
refused corrupted bytes. The changed binding and same-geometry changed
result refused. Both transactions included one proved positive-fee Dust
spend, applied under default strictness, and refused exact replay with
identical complete ledger bytes. Mutated IR and checked-program bytes
refused before keys or state.
The local orchestration expects the v2 receipt, and the Linux workflow
is configured to retain the generated proof and replay evidence and
verification logs. The constructor and wide-zero qualification results
below record the migration of the earlier workflow steps.

The original literal Vector projection and the separate constant-valued
Vector index source each passed both branches of the `witnessed` circuit
with ZKIR 3.2.0 at k7 and 71 rows. The complete Rust, IR and five checked
programs matched for each source. Their generated API gates passed live
TypeScript parity, source refusals and Rust compile failures. Fresh v3
standalone proofs passed separate verification, and the changed binding,
input, output and corrupted-proof controls refused. All four distinct
transaction-bound v3 proofs funded and applied with default strictness,
then refused exact replay with identical ledger bytes. The two Map cases
also passed a fresh rerun through the shared v3 application code.

Source preflight now checks the reviewed Ledger 9 bindings for 36 Rust
test and support files and 16 active TypeScript captures alongside the
original review and capture records. The Rust edits add the optional v3
operation argument or select fresh Ledger 9 captures, with formatting
adjustments. The gate passed all 37 pinned sources. Workspace behavior
remains a separate qualification.

## Constructor Vector qualification

The maintained generated API gate passed all 132 commands on macOS arm64
with the original compiler recipe at `a0d81c197`. It kept all 14 sources,
the independent Scheme comparison, and the 24 Rust and TypeScript cases.
The case roster covers 17 successes and seven constructor errors. The gate
also exercised 68 post-initialization routes, 34 public replays, generated
SDK and consumer Clippy, source mutations, and malformed IR refusals.

Released ZKIR 3.2.0 modeled the 42 original exports in a separate probe.
The 14 reads were k6 with 34 rows. Each source's `advance` and
`advance_other` were k7 with 78 and 79 rows respectively.

Port the maintained model observer, proof preflight, and isolated proof
consumer together. Bind the exact source, raw IR and checked programs to
the v3 model and verify the released k7 parameters and Dust spend material
before key generation. Retain all 17 proof cases, the changed statement,
wrong verifier and corrupted proof controls, and separate verification.
Each successful case still needs a distinct funded transaction proof,
default strict application and byte-identical ledger state after replay
refusal. Constructor equality and wide-zero retain their own qualification
gates.

## Remaining workspace qualification

The maintained generated functional gate now selects Ledger 9 for all
23 source fixtures. Its 56 Rust methods and 160 four-route scenarios
passed, along with generated-consumer Clippy. Seven additional ADT
fixtures now compare full Ledger 9 state bytes against fresh TypeScript
captures. Their eight Rust tests passed, with historical observations
retained alongside the new captures.

The terminal default-feature arm64 workspace run recorded 3,198 passes,
234 failures and seven ignored tests before the ADT update. Of the
234 failures, 224 showed a Ledger 8 state serialization mismatch and
ten showed retained DID reducer provenance mismatches. Rustdoc also
failed on 289 targets in the reused build directory. One direct
reproduction traced the error to a proc-macro metadata hash mismatch,
and the single-package doc check passed with its separately compiled
runtime. Rerun the full workspace doc qualification in a fresh,
exclusive build directory.

The broader workspace behavior, remaining proof consumers and required
Linux integration lanes remain open.

Ten DID reducer fixtures now bind separate Ledger 9 TypeScript captures.
The exact compiler regenerated all ten Rust libraries byte-for-byte.
The 59 cases retained their reviewed order, inputs, outcomes, transcripts
and gas. State bytes and capture provenance were refreshed using Compact
Runtime 0.17.0 and Onchain Runtime 4.0.1. The original Ledger 8 captures
and review manifests retain their exact hashes. The 26 locked Rust
integration tests passed, including the ten provenance tests.

The maintained Constructor Vector model observer passed all 42 v3 models
and its membership refusal controls. The first exact conditional proof
probe refused a prepared operation that had lost its installed v3 IR.
The proof consumer now uses the observed-call path in both typed routes
and keeps the malformed replay refusal. Full Constructor Vector proof
qualification requires a fresh run of the corrected gate.

Both conditional cases passed a focused run with the observed-call repair.
Each standalone proof passed separate verification, including the wrong
verifier and corruption controls. A distinct v3 proof funded each transaction
with one positive-fee Dust spend. The transactions applied under default
strictness and exact replay was refused with identical ledger bytes.
The complete 17-case gate passed at `3da993bba`. It retained 28 fresh
key pairs for the 14 source variants and 17 standalone verifications,
including the wrong-verifier and corrupted-proof refusals. All 17
separate funded transactions passed default strictness and refused
exact replay with byte-identical ledger state.

The Constructor Equality port retains the three cohorts and both source
scopes. The released v3 tool modeled all 96 exports at k6 and 34 rows for
`read`, k7 and 78 rows for `advance`, and k7 and 79 rows for
`advance_other`. Independent TypeScript captures using the Ledger 9
runtime pair passed all 16 base, 30 boundary, and 105 tuple cases.
The 54-command tuple scope gate and the 19-command base API gate passed
at `11769f654`. The required proof callers preserve all selected counts
and verify each retained standalone proof separately. The base cohort
passed all 16 cases at `11769f654`, with 16 fresh key pairs and separate
verification of all 16 standalone proofs. It refused corrupted proofs
and distinct verifiers. Sixteen distinct funded transactions applied
with default strictness and refused exact replay with byte-identical
ledger state. The boundary cohort also passed all 30 cases at the same
commit, with 16 fresh key pairs across eight sources. All 30 separate
standalone verifications refused corrupted proofs and distinct verifiers.
Each distinct funded transaction passed default strictness and refused
exact replay with byte-identical ledger state. The tuple cohort passed
all 105 selected cases at the same commit, with 32 fresh key pairs
across 16 sources. Separate verification refused corrupted proofs and
distinct verifiers. The input, output, binding, and preimage controls
passed for each selected case. All 105 distinct funded v3 transactions
applied under default strictness and refused exact replay with
byte-identical ledger state.

Wide-zero multiplication passed the maintained generated API gate for the
original and conditional sources. The two ordinary entries model at k7
and 102 rows, and the two witnessed entries at k7 and 82 rows. The Ledger 9
proof caller verifies k7 material before fresh key generation for the two
originally selected ordinary entries. Both cases passed at `df2d240a1`
with separately verified 3,824-byte standalone proofs and distinct
3,824-byte transaction proofs. Each default-strict transaction included
one positive-fee Dust spend and refused replay without changing ledger
bytes.

Six maintained API gates passed at `c8576565b`. Source-map publication
ran 32 commands with the original 28 path cases and three private
manifest controls. Direct Fold ran 48 commands, Field return wrappers
14, tuple return wrappers 22, Unit initializers 30, and the nested
product request field gate 64. Their original behavior and refusal
rosters remain in force.

The ten Direct Fold sources regenerate exact bound IR, origins,
capabilities, and checked programs with Ledger 9. Their released v3
models use k6, k7, and k8. The proof migration verifies those parameters
before fresh key generation and retains all eleven executions.
The 64-command Direct Fold proof gate passed at `9a3518c68`.
It separately verified all eleven standalone proofs and rejected their
corrupted forms. Eleven distinct funded v3 transactions applied with
default strictness and refused replay with byte-identical ledger state.

At `119d114de`, the maintained Field wrapper, tuple wrapper, and Unit
initializer gates passed all two, four, and four selected cases on
macOS arm64. The gates verified k7 material before fresh key generation
and preserved the complete modeled export rosters. Separate processes
verified all ten standalone proofs and refused corruption. Each distinct
funded v3 transaction passed default strictness with one positive-fee
Dust spend and refused replay with byte-identical ledger state. The
Unit gate exercises later calls and state committed by initialization.

Twelve constructor fixtures now use fresh TypeScript state captures
produced with Compact Runtime 0.17.0 and Onchain Runtime 4.0.1. Only
serialized state fields changed in the captures, and the historical
Ledger 8 captures retain their original bytes. The Rust List fixture
now includes all five source exports in its installed operation map for
the exact state comparison. All 15 locked Rust integration tests across
the twelve packages passed on macOS arm64 at `ae48c02a6`.

The released v3 model probe covered all 70 stateful vector, nested
product, component-vector, and outer-vector exports. All 36 selected
exports fit the existing automatic k8 limit. The maintained product
proof callers still need migration and fresh qualification. Required
Linux integration and distribution qualification remain open.

The vector component gate now uses the released ZKIR v3 tool and binds
complete checked programs captured with the maintained repository-relative
source operand. The three selected raw IR files match the original bytes.
The corresponding programs carry Ledger 9.1.0.1 and preserve all other
content. The Ledger 8 program and model files remain available.

The maintained vector component API protocol passed all 170 commands on
macOS arm64 at `72aa8d16a`. The 24 complete sources produced 35 TypeScript
cases and 35 Rust tests, with 136 stateful routes, 58 public transcript
comparisons, 14 compile-fail controls, 13 malformed-IR controls, and
three typed source mutations. The complete proof gate retains three
selected k8 exports and separate standalone verification. The native
runner, complete model check, and pre-key refusal controls passed. The
corrected run reached material verification and refused a local cache
that lacked the k8 SRS. With verified upstream k8 material, all three
selected cases passed at `72aa8d16a`. Each standalone proof was
3,824 bytes and passed separate verification, including corruption and
wrong-verifier refusals. Each distinct funded v3 transaction applied with
default strictness and refused exact replay with byte-identical ledger
state.

The nested component and component Vector product callers now select
the released v3 tool. Their complete source models retain 14 and 16
exports respectively. The four and fourteen original proof selections
retain their complete checked-program bindings and typed negative
controls. The nested component gate passed at `5e99bec69` on macOS
arm64, including the 73-command API protocol and 16 pre-key byte and
membership refusals. It generated four fresh key pairs at k7 and k8.
Each standalone proof passed separate verification and refused
corruption. The four distinct funded v3 transactions applied with
default strictness and refused exact replay with byte-identical ledger
state.

The component Vector API protocol passed all 88 commands at
`d16987d11`. The proof gate stopped before key generation because the
original 14-case selection omitted the family `branch`, which now
fits k8 at 213 rows. The corrected selection covers all 15 in-cap
exports and includes the existing typed `branch_left` case. The
original direct export remains at k9. At `15bd923c2`, all 15
selected proofs passed on macOS arm64. The gate checked all 21 pre-key
refusals and separately verified each fresh standalone proof,
including the corruption refusal. Each distinct funded v3
transaction applied with default strictness and refused exact replay
with byte-identical ledger state.

The outer Vector port also includes `branch_left` and keeps both
branches in the parity tests. All 16 exports now fit k8, including
`family/branch` at k8 and 209 rows. The gate generates the unchanged
vector component `helper/run` with the same admitted compiler into a
private fixture, checks its k9 and 288 rows, and uses it for the
over-cap refusal before key generation. The API protocol passed all 91
commands at `15bd923c2`. The proof gate stopped before key generation
when the model command wrote its binary IR alongside the intact donor.
The corrected gate authenticates that binary and binds the original raw
IR in the refusal. The local retry at `221d9a690` passed all 91 API
commands and 22 pre-key refusals. It generated fresh keys for all 16
exports on macOS arm64. A separate invocation verified every standalone
v3 proof and refused corruption. All 16 independently proved funded
transactions applied with default strictness and refused exact replay
with byte-identical ledger state. The artifact readback checked the
standalone and transaction proof bytes, the per-call event records, and
the unchanged raw donor.

The workspace rustdoc rerun passed at `15bd923c2` with Rust 1.99,
the locked Ledger 9 graph, and a fresh exclusive target directory.
Rustdoc completed all 303 targets and ran seven passing doctests.

Eight expression and assertion fixtures now use fresh paired
TypeScript captures at `093467ed0`. Their 82 serialized contract-state
fields use Ledger 9. The three wide-add diagnostic locations track the
current source lines and preserve the error text and values. Historical
captures retain their original bytes. All 14 focused Rust tests passed
with all features on macOS arm64. At this head, the behavioral
workspace run completed 733 targets with 3,244 passes, 182 failures,
and seven ignores. The 99 failing targets all appear in the earlier
failure roster. All 182 failure messages show a v6/v8 contract-state
encoding mismatch. Further assertions can run after those comparisons
are repaired.

Another 31 fixtures now bind fresh captures from their original
TypeScript producers at `061640db6`. These captures refresh 177
serialized contract-state fields. Witness effect order also records
the current compiler, Scheme, and runtime provenance. The canonical
output capture preserves spend-set membership and the exact ordered
query trace. Its Rust test keeps the established set comparison and
all execution-order checks. The all-features native run completed
66 targets with 88 passes and one failure. The failed test also read a
separate Ledger 8 capture for the untaken impure call argument.
The original TypeScript producer supplied fresh state and current tool
provenance for that case at `3af6ccba3`. Its full public program,
ordered query trace, and other scenario values agree with the
historical capture. All 12 package tests passed on the focused rerun.

Eleven additional scenario captures at `6e324f9f9` refresh 124
serialized state fields. The native tests completed 13 targets with 18
passes and two failures against a separate historical Zerocash
constructor, mint, and spend capture. At `4991d2a73`, the fresh
Zerocash capture reproduces the historical leaf, all 32 siblings,
and their directions. The three DID relation reducers preserve all
22 scenarios, including their exact ordered programs, query costs,
and refusal cases. All nine focused tests across the four packages
passed with Rust 1.99 on macOS arm64.

At `514df1d5e`, Coracle withdraw preserves exact spend and nullifier
membership under the existing set comparison. Micro DAO vote commitment
preserves exact commitment-to-index pairs and ordered offer outputs.
For Coracle guess, the fixed per-query budget that succeeded on Ledger 8
now fails on Ledger 9 after six successful TypeScript queries. Native
and recorded Rust both report the corresponding out-of-gas error and
match the captured witness order. The zero-budget refusal and the
unlimited positive paths also pass. All three focused tests passed.

At `d5747ec1f`, five Election and seven conditional captures refresh
61 state fields and preserve their non-state behavior. The original
conditional producer also records current tool provenance for the
opposite-state case. The focused run passed 16 tests and reported five
remaining v6/v8 comparisons. Those tests still reference the distinct
Election owner-operation, base ternary, conditional Counter, and
shared direct behavior fixtures. At `7fc3f055a`, all four captures
refresh 42 state fields. The Election owner scenario reproduces both
ten-level Merkle paths from actual execution, including the leaves,
siblings, and directions. For the shared direct capture, the staged
producer changes only the required runtime version from 0.16.101 to
0.17.0. Its reviewed original bytes and case inventory are retained.
Both the full Election and ternary package tests pass. All three Rust
consumers pass the shared direct tests.

At `cea38ce25`, 14 Registry, assertion, literal, and pure-call captures
refresh 93 state fields. The shared Call Registry producer uses the same
version-only staging adjustment as the direct behavior producer.
All 43 focused tests across the five affected packages pass, including
the three older state comparisons exposed by the shared direct run.
The locked offline workspace run at this signed head completed 733
targets with 3,365 passes, 61 failures, and seven ignores. All failures
report v6/v8 state comparisons. The 41 failing targets are a subset
of the earlier 99-target roster.

At `f6ae8e51c`, 16 collection, conditional, Merkle, and shielded
effect captures refresh 111 state fields. Their captured programs,
effects, and other scenario values agree with their historical
counterparts. The focused run across 13 packages passed 33 tests and
found six comparisons against separate historical captures.

At `d89c838f9`, four Coracle and Micro DAO captures replay all 88
historical scenarios with Compact Runtime 0.17.0 and the published
[`@midnight-ntwrk/ledger-v9` 1.0.1 WASM package](https://www.npmjs.com/package/@midnight-ntwrk/ledger-v9/v/1.0.1).
The captures retain 113 fresh state fields and 25 successful partition
pairs. Six successful calls move from the fallible slot to the
guaranteed slot. All 25 partitions have changed storage gas figures.
The captures preserve exact public programs, event order, commitment
indices by key, and shielded claim membership. The Rust tests now invoke
the matching published partitioner and compare both slots, program
length or full program as captured, effects, and all four gas dimensions.
The first Rust run exposed the exact mint integer represented as a
decimal string by WASM and a JSON number by Rust. At `7faaa6c4b`,
the shared comparison preserves every mint key and integer while
checking its value across both encodings. All four focused tests pass.
The partition captures represent seeded local calls, with funded
proof and replay covered by their own gates.

At `cdaa5e344`, nine new constructor and collection captures refresh
35 state fields. The guarded arithmetic, Merkle root, nested Set action,
empty Set and Map, and chunked qualified coin tests retain their exact
historical outputs and query assertions. All 22 focused tests pass,
closing the six comparisons from the previous collection run.

The local Ledger 9 Counter harness applied a funded deployment at its
generated address under default strictness. A separate funded call
produced a distinct transaction-bound v3 proof and applied the expected
generated Rust transition. Exact replay returned `IntentAlreadyExists`
with byte-identical ledger state. The new confirmed-state test at
`704b1d23a` loads the exact applied contract and deployment artifacts.
All three tests pass, including the malformed current-state refusal and
rejection of both retained ABI-18 artifacts. The generated observed-call
consumer points to the new state. The isolated consumer test passed with
the matching retained verifier. The full compiler proof integration gate
remains open.

At `19947cbf5`, five PM-19252 and native own-key captures and three
witness collection captures refresh 24 state fields. They preserve
the witnessed values, exact query costs and operation programs, and the
native key routes' proof-free behavior. All 33 focused tests across six
packages pass.

At `5beb360f4`, seven helper and oracle captures refresh 19 state
fields. Tiny's gas, query tags, public transcripts, and private output
counts also reproduce the historical capture exactly. All 29 focused
tests pass.

At `f6cc81b91`, fresh TypeScript runs cover both composition layouts,
the ten shielded-send cases, and the five successful shielded-receive
cases. Receive accepts the two values that exceeded the original b8
descriptor. It refuses negative and overflowing values before queries,
outputs, or state changes. The historical b8 refusals and commitments
remain checked. Send compares exact commitment-to-index pairs and
claim membership, while preserving transcript order. All 11 focused
tests pass.

At `dcf2e70f6`, the local TypeScript runtime rejects a raw Jubjub
scalar outside the canonical range for both multiplication builtins.
Explicit reduction still works. With the original generated wrapper,
the unmodified 0.17.0 package reproduced the acceptance of the raw
order. The runtime rebuilt from this branch over the same pinned
onchain package passed the complete 82-test TypeScript runtime suite.
The regenerated Jubjub capture retains seven reduced calls, two raw
calls and five refusal controls. It matches the original-reference
results, exact query programs and gas, and rollback behavior. The
serialized Ledger 9 states and the new range diagnostic are recorded
separately. The 14 focused Rust behavior, provenance and native tests
pass. The published runtime package remains unchanged.

Later focused runs now pass for all 41 targets from the earlier
workspace failure roster. A fresh locked workspace run is required
to verify that result across the full corpus. The compiler integration
preflight compared the complete mixed-width source IR without keys.
The full compiler proof integration gate remains open.

## Workspace recheck and root Let proof

At `180622cf4`, the locked arm64 workspace libraries and tests ran the
same 733 targets as the previous run. The result was 3,417 passes,
11 failures and seven ignores. Every earlier failing target passed.
The 11 failures were DID provenance checks for the TypeScript
`built-ins.ts` digest after the Jubjub fix.

At `3fdf52343`, 18 fresh captures from the rebuilt runtime reproduce
the exact behavior and state bytes of the previous Ledger 9 captures.
The capture bindings identify the actual rebuilt TypeScript and the
compiler used. The point-map and nested-map wrappers have new
digests. The original DID wrapper, raw IR and Rust library retain
their prior bytes. The independently generated raw source-origin
output differs and remains outside this recapture's admission. The
historical Ledger 8 fixtures and original bindings retain their
digests. All 14 focused provenance tests and seven Rustdoc tests
passed. The Rustdoc run covered 303 targets.

At `2e29bdcdf`, the Coracle and Micro DAO fixture registry pins match
the manifests that already declare the exact Ledger 9 dependency.
Fixture freshness passed for all 284 entries. Workspace Clippy passed
with all features and targets enabled and warnings denied. Seven
named shielded and Zswap scenarios passed source admission. Their
proof lanes remain open.

With the pinned ZKIR tools available, the previous core gate reached
the root Let fixture and exposed its v2 proof consumer. The port at
`f874af360` binds the full original Rust IR and exact v3 circuit
before proof consumption. The official tool models `step` at k7 and
68 rows. A fresh 3,824-byte standalone proof verified in a separate
process. The checks refused a changed binding, changed input and
corrupted proof bytes. The generated native, recorded and observed
routes agree on the independent Field return and the stored Cell.
A funded deployment installed the complete v3 operation under default
strictness. A distinct 3,824-byte transaction-bound v3 proof applied
the call to that state under default strictness. Exact replay returned
`IntentAlreadyExists` with byte-identical ledger state.

The Rust 1.99 workspace library and test run at `5d037d219` passed
3,428 tests across 733 targets, with seven ignored. The installer was
excluded. The accompanying proof-runner Clippy check found a redundant
dereference in the root Let deployment check, corrected at `dee637ef3`.
The core compiler gate passed the root Let proof and then stopped at
the composite-return fixture's v2 proof reader.

The port at `02141a85d` binds the full retained Rust IR and generates
fresh v3 keys for `snapshot`, `reverse`, and `nested`. The modeled
circuits are k7/119 rows, k7/113 rows, and k8/131 rows respectively.
The native, recorded, and observed routes agree on the results and
witness order. The empty `snapshot(false)` call still refuses
preparation with `EmptyTranscript`. Each standalone proof verifies in
a separate process and refuses corrupted bytes and a changed binding.
The `snapshot` proof also refuses a changed Boolean input. Each case
deploys the exact operation and applies a separately proved, funded
call under default strictness. The three reads preserve contract state,
and exact replay returns `IntentAlreadyExists` with byte-identical
ledger state. Ledger 9 proof qualification for the k10 `planned`
circuit remains open in the separate composite Zswap scenario.

The next core run passed root Let, composite returns, and the
proof-runner Clippy check. It stopped at the assertion fixture's v2
reader. The port at `ab6e75c16` binds the current raw Rust IR, generated
library, and both raw v3 circuits before key generation. The older
IR fixture retains its original source positions. The current IR
differs only in seven positions following the source header, and
formatting the generated library with Rust 1.99 reproduces the linked
Rust fixture byte for byte. The `checked` Uint<64> result models at
k7/109 rows and `unit_result` at k6/41 rows. Both passed the original
false-guard refusal, separate standalone verification with changed
input, binding and corruption controls, and funded default-strict
deployment and application using distinct transaction proofs. Both
reads preserved state and refused exact replay without ledger mutation.

The core run at `4fa6279a8` passed the assertion cases and then
exposed the effectful-return fixture's v2 proof reader. At
`567407cee`, both `choose` branches on the original source and the
separate wide-value source passed v3 proofs at k7/107 rows. The primed
branch does not read `next`, so a changed value still satisfies its
selected transcript. The original proof refuses the changed public
commitment for either branch. The gates retain typed results, witness
selection, gas, and native, recorded, and observed state parity.

At `07702f47e`, both Counter `lessThan` outcomes passed with
`compare` at k7/78 rows. The current compiler's IR differs from the
retained Counter IR only in its schema version. The literal
Bytes-to-Field snapshot passed at k6/47 rows, including its manual
transcript comparison and generated typed result. The original strict
selector reaches the same Ledger 9 snapshot checks. Fresh Rust output
for both scalar fixtures matches the linked libraries after Rust 1.99
formatting. The source gate passed the six literal cast rejection
cases and the corresponding TypeScript overflow timing checks.

All seven primary cases across these sources passed separate
verification with corruption controls, funded deployment and a
separately proved call under default ledger strictness, and exact
replay refusal without state mutation.

At `5d2d856a8`, proof-runner Clippy and the Python harness passed.
The core compiler gate passed these effectful and scalar cases and
then stopped at the positional Counter proof runner's v2 reader.
A minimal current Counter and Cell artifact set reproduces the
refusal. The signed JavaScript decoder candidate at `84941f2d9`
pins `@midnight-ntwrk/ledger-v9@1.0.1`. It round-trips seven actual
funded Rust deployment and call pairs, checks the proof and the
positive-fee Dust intent, and refuses mismatched addresses and trailing
bytes.

At `6b3d3c157`, the positional baseline proves both direct and
observed Counter calls plus the Cell write and read. The exact
generated Rust IR, library and raw ZKIR are checked before key
admission. The four cases retain the Counter's exact public statement,
typed state and return checks, and missing operation, wrong verifier,
wrong address, stale state, and trailing observed-state byte refusals.
Direct and observed Counter preparations produce the same pre-proof
bytes and independently apply to the same contract state. Each case
passes separate standalone verification, strict funded deployment and
call application, and exact replay refusal without changing state.

The decoder at `7f14a0be9` round-trips the newly exported funded
Counter deployment and call using the pinned Ledger 9 JavaScript
package. The files match the exact Rust application receipts. The
decoder also refuses a mismatched deployment. The positional fixture
uses the local funded ledger and its clock. The historical devnet
handoff remains documented on the Ledger 8 branch.

The exact core run at `0205fb9ec` reached the parameterized Counter's
v2 reader after the four baseline proofs and wallet handoff. At
`0242fd5fb`, all nine optional positional scenario modules share
the Ledger 9 v3 proof path. Each call installs the verifier and
the binary IR reconstructed from its raw ZKIR, retains the scenario's
original typed state and transcript checks, and checks funded
deployment and a separately proved call under default strictness.

The core run exercised 186 optional positional proof cases. The same
186 cases passed separate verification, funded deployment, funded
application, and exact replay refusal with byte-identical ledger
state. The count includes 44 direct and observed pairs that produced
identical pre-proof bytes and independently applied to equal contract
state. Eleven retained Counter and witnessed Cell proofs also
verified with the final binary. The positional verifier refused a
different verifier key and mismatched raw and binary IR. Scoped
Clippy passed after removing the now-unused v2 parity helper.

The full core run reached the named test-center Counter after the
positional suite. At `5ccfb8561`, a focused local run qualified 24 cases
across 14 named commands for that Counter, composite Cell, plain and
historic Merkle operations, and inline type-scope hash assertions. The
current compiler produced the Rust linked into the runner for all seven
source fixtures. The Counter also checks its exact generated Rust IR,
library and raw ZKIR before loading the verifier. This distinguishes the
Unit-witness source from the ordinary Counter, which has the same raw
`increment` ZKIR.

Each case retained its original typed state and transcript checks and
passed standalone proof verification in a separate process, changed
binding and corruption refusal, funded deployment and an independently
proved call under default strictness. Replaying the call returned
`IntentAlreadyExists` and preserved identical ledger bytes. The runner
refused a substituted Counter IR and an external proof provider.

At `91349673e`, all five named election commands passed. The current
compiler reproduced the retained election IR and linked Rust. The
eleven cases cover the Unicode topic, four phase transitions including
the stable final phase, two voter insertions with ordered witnesses,
and both commit and reveal ballots. Each passed separate proof
verification and corruption refusal, funded deployment, an
independently proved default-strict call and exact unchanged replay
refusal. The topic, phase and voter circuits model at k13. Commit and
reveal model at k14. Missing and substituted source were refused before
key loading. Several cases deploy their exact seeded pre-call state to
test a particular transition in isolation.

At `680dee9d9`, Zerocash mint, both spend roots, and both empty and
Unicode bulletin-board post and take-down cycles passed all seven fresh
proof cases. The current compiler reproduced the retained IR and linked
Rust for both fixtures. Each case passed separate verification and
corruption and changed-binding refusals, funded deployment, an
independently proved default-strict call, and exact unchanged replay
refusal. The Zerocash spend cases used the original contract-owned
commitment tree and preserved ordered witnesses, private transcript,
ciphertext and commitment index. Each command refused substituted IR
before key access.

At `8013f70b7`, nine required declared-argument and witness commands
and two additional related selectors passed thirteen fresh Ledger 9
proof cases. The current compiler output matched the Rust linked into
the runner. These cases preserve declared Field commitments, vector
witness values and discarded results, typed Field helper calls,
persistent and transient pair hashing, and Boolean assertions. Each
case passed separate verification, binding and corruption refusal,
funded deployment and an independently proved default-strict call.
Exact replay was refused with identical ledger bytes. Both commitment
selectors refused substituted source. Fourteen fixture tests and two
source-refusal tests passed. The follow-up `a4090b951` completes the
required source license header.

At `8a5009ef5`, eleven conditional, sequential and pure-call
commands passed 33 fresh Ledger 9 proof cases. The current compiler
reproduced the linked Rust for all five source fixtures. The checks
cover both branches and seeded ledger state, ordered unsigned writes,
typed Field, curve and vector arguments, witness execution and Set
insert and remove behavior. The unsigned sequential command refused
substituted binary IR. Separate verification, binding and corruption
refusals, funded deployment, independently proved default-strict
application and exact unchanged replay passed for all 33 cases.
Twenty-four fixture tests also passed.

At `1d6878f7a`, the seven required asset registry and Schnorr
commands and the additional strict Schnorr selector passed 14 fresh
Ledger 9 cases. Both Schnorr selectors enforce exact source and
input/output binding. The Ledger 9 Schnorr IR uses three different
temporary names. It is pinned separately from the historical fixture,
and the current compiler reproduced the linked Rust. Asset tests
preserve the custody, record, watch, removal and grant checks, as
well as state seeded for update cases.

Each case passed separate proof verification, binding and corruption
refusals, funded deployment, a distinct default-strict call proof,
and exact unchanged replay refusal. The final signed runner also
verified all ten retained asset proofs. Scoped Clippy and 27 fixture
tests passed.

At `79814169a`, the final eight named commands in the core proof
gate passed twelve fresh Ledger 9 cases. Current compiler output
matched the linked Rust for all eleven source fixtures. The checks
preserve Let returns, unused reads, identity-map writes, stateful
pure returns, wide casts, unsigned calls and witness assertions.
Both mixed-width circuits preserve their original rejection controls.
Each case passed separate verification, funded deployment, a distinct
default-strict call and exact unchanged replay refusal. The final
runner also reverified nine retained cases from the initial candidate.
Twenty-eight fixture tests and two mixed-width source tests passed.

The Map oracle acceptance check had retained the pre-formatting hash
of one Rust test. Rust 1.99 formatting reproduced the active bytes
exactly from the previously pinned test. Only that active hash was
refreshed. The Python suite reported 522 tests with 20 skips, and
all 37 pinned oracle sources passed acceptance.

At `faa59842f`, the complete macOS arm64 core gate passed with
`--core-only --consumer --proof`. It recorded 311 fresh standalone
proofs with separate verification and corruption refusal, 311 funded
deployments and distinct strict call proofs with exact unchanged replay
refusal, and 44 manual and observed parity pairs. The Ledger 9
JavaScript wallet decoded and re-encoded the exact deployment and call
bytes.

The first offer-aware case in each native shard initially sent v3
artifacts to a v2 reader. At `1eaea378c`, Qualified Coin Cell, native
Zswap transfer and both shielded merge lanes use the Ledger 9 v3
path. Five fresh standalone proofs passed separate verification and
corruption refusal. Four funded offer cases passed default-strict
deployment, distinct call proof and application, and exact replay
refusal with unchanged ledger bytes. Qualified Coin Cell also
preserves its exact unfunded balancing refusal. The composed signed
runner passed all-targets, all-features Clippy and separately reverified
all five retained standalone proofs. The focused state-only Counter
check passed with the shared offer helper.

The next baseline probes passed the native StatefulStruct check and
found the same v2 reader mismatch in Kernel shielded effects, field
observation and shielded send. Those three maintained proof selectors
passed together at `5289b8642` on macOS arm64. They recorded 19
fresh standalone proofs with separate verification, changed binding
and corruption refusals, and 12 distinct funded default-strict call
proofs with exact unchanged replay refusal.

Kernel shielded effects preserves the five unmatched-offer refusals
and the empty selected branch. The funded mint uses the exact output
commitment and index. Field Observation covers all eight existing
proof cases and retains the empty optional branch and selected-input
refusals. A fresh TypeScript run reproduced its 23 observation rows,
which the generated Rust fixture checks. Shielded Send covers direct
full, direct partial, and trusted-observation calls. It preserves the
input-index, output-order and spent-nullifier controls. The focused
runs also refused substituted source and proof artifacts.

The native model measured the complete raw v3 circuit sets of 14
original sources used by the proof shards. The verified built-in
proof material already contributes k13 through k15, including the
k15 needed for shielded merge and send. The native shard workflow
now explicitly requests k9, k10, k16 and k17 alongside k5 through k8.
The separate core and wallet workflow requests k5 through k11,
matching the local core material. Both rosters passed local
verification using the locked digest tables.

At `a9ed875ea`, the maintained MicroDAO advance, voting-token and
reveal selectors passed six fresh standalone v3 proofs with separate
verification and distinct funded strict application and replay. The
cases preserve the original explicit prior states, token derivation
at the deployed address, vote tallies, private and witness behavior,
and duplicate reveal refusal. Fresh TypeScript captured all 40
retained rows byte for byte. The three selected v3 circuit recipes
also reproduced their raw and binary IR and prover and verifier keys.
The four MicroDAO offer scenarios still require their migration.

The active fixture registry now pins the three proof wrappers'
exact bytes. The historical comparison permits just those verified
wrapper changes alongside the previously accepted deltas. The full
Python suite passed with 522 tests and 20 skips, and all 37 pinned
oracle sources passed.

At `3ca032bdf`, six maintained native selectors passed on macOS
arm64. The composed run verified 17 fresh standalone v3 proofs
separately and applied 16 distinct funded default-strict call proofs
with exact unchanged replay refusal.

Shielded Receive now covers the direct, wallet-funded and trusted
observation policies. The wide `2^64` case remains a standalone
proof. The zero receive and both wallet-funded cases validate the
funded application, and the original external wallet input and
spent-nullifier refusals remain in scope. The shared offer application
also passed the full, partial and trusted Shielded Send regression.

Terminal lexical returns preserve all four proved return paths,
including the witness-driven observed call. Coracle guess proves
both colors from explicit prior states and retains each exact
repeated-turn refusal. Both sources retain exact generated Rust,
complete raw ZKIR and selected binary and verifier pins.

Composite Zswap proves the original zero-output plan and funded
transfer. Canonical Output Order proves both commitment sort orders
with the exact sent and change indices and stored change. The
retained receipts record distinct application proofs and byte-exact
replay results for both suites. Fresh TypeScript reproduced 52 rows
across Receive, lexical return, Coracle guess, Composite Zswap and
Canonical Output Order. The affected generated Rust fixture tests
passed.

Transient Receive/Send and the original Coracle offers passed on macOS
arm64. Coracle at `925d40fda` covers six fresh v3 proofs and separate
verification, funded default-strict application, unchanged replay and
the selected fallible rollback controls. Ledger 9 constructs a wholly
fallible offer only for the explicit blue-start and withdrawal policies.
The guaranteed and automatic placement paths retain their existing checks.

Original DID at `26860d7c0` passed 16 lifecycle and 19 relation cases
using compiler 0.31.211. Each case separately verifies its fresh
standalone v3 proof and refuses a corrupt proof. A distinct v3 proof
applies in a funded default-strict transaction and refuses replay with
identical ledger bytes. The compiler models the original twelve exports
at k11 and k12. Every required verifier is installed, with binary v3
IR on the selected calls to fit ordinary deployment fee limits. The
nineteen relation cases also emitted versioned public-only interchange
with the exact Ledger 9 producer and transaction identity. The gate
uses the active Ledger 9 captures alongside the retained Ledger 8
history. Constructor execution lies outside these case selections.

The first draft CI run for PR #725 found a stale Rust MSRV lane,
a missing compiler version bump and license-header regressions. Both
Rust 1.99 consumer checks and the full-diff header audit passed locally,
and the bumped 0.31.211 compiler built with Nix. The exact compiler
source passed all 3,887 checks, including both JavaScript ZKIR modes,
and the 284 generated Rust fixtures are fresh. Both packages verified
and reproduced their release manifest. The offline archive consumer
generated six contracts through the shared-source compiler interface,
resolved the exact packaged runtime and macro graph, and passed its
Rust tests and compile-fail controls.

The seven remaining MicroDAO offer cases passed separate fresh v3
proofs, funded default-strict application, selected fallible rollback,
and exact replay refusal. The 28 DID reducer cases cover 13 fixtures
and 19 fresh key sets. Nine live TypeScript reducer captures matched
the reviewed Ledger 9 bytes. All reducer cases passed separate proof
verification, funded application, and unchanged replay.

At `88ad250dd`, the full local core and generated consumer gate
passed 311 separate proof verifications, funded applications and
unchanged replays. The Ledger 9 JavaScript consumer reproduced the
funded Counter deployment and call bytes. Native shards 0 and 2
passed. The shard 1 wide-add check was corrected to compare against the
current runtime compatibility record. At `98c041dd`, shard 1 passed
its complete rerun, including both witness-composition controls.
The same head proved all seven AccJubjub apply cases with a fresh
explicit k12 key, separate verification, strict funded application
and byte-identical replay refusal. Both raw cases retain their
behavior scope, and the live TypeScript capture matches the active
Ledger 9 bytes and preserves the independent historical oracle.

These are macOS arm64 results. The first full parent run completed
compilation and formatting for all 286 registered sources and matched
the generated Cargo consumers. It stopped when the original Zerocash
source-scope check compared a complete emitted library to an include
wrapper. The corrected source-scope check compares complete, formatted
libraries using Cargo's registered build-script artifact for eight
cohorts. The flat fixture checks still compare checked-in bytes. The
focused scopes passed and the Zerocash check rejected an unrelated
consumer and independently changed emission. The package archive with
the current setup guide passed its offline six-contract consumer again.

The complete maintained parent parity rerun, fresh review of the
composed update, and exact-head required Linux CI remain part of
integration.

### Standalone stateful product Vector qualification

The standalone stateful product Vector gate now uses the Ledger 9 functional
profile and emits v3 ZKIR. The 25 original sources reproduced byte-identical
independent and historical raw IR. All 25 checked Programs match the current
Ledger 9 goldens. The original Ledger 8 goldens are retained. The isolated
gate passed 32 TypeScript/Rust cases, 25 strict SDK checks, seven source
refusals, nine malformed IR refusals, and four changed-producer controls.

Signed source `f43afeec0` proved three selected cases on macOS arm64. Both
admitted exports used fresh k8 keys from ZKIR 3.2.0. Each standalone proof
was verified in a separate process, and a distinct funded default-strict
transaction proof applied the call with one positive-fee Dust spend. Replay
returned `IntentAlreadyExists` with identical ledger bytes. The gate refused
changed IR, checked Programs and raw ZKIR before key generation and refused
a genuine k9 model under the existing automatic k8 limit. Corrupt proof,
wrong verifier, changed binding and same-geometry changed result controls
also passed. This proof roster covers both typed branch results and the Field
export. The other standalone functional families remain separate work.

### Standalone stateful local Vector qualification

Signed source `0e0584a5f` passed the standalone Ledger 9 gate on macOS arm64.
The 24 original sources matched the independent and historical raw IR.
Their 24 checked Programs match the Ledger 9 goldens, with separate Ledger 8
goldens retained. The native gate passed 34 TypeScript cases, their Rust
counterparts, 24 strict SDK checks, seven source refusals, eight malformed IR
refusals, and four changed-producer controls.

ZKIR 3.2.0 generated fresh k7 keys for `run` and `run_field`. Both unsigned
branch cases and the Field case produced standalone v3 proofs that verified
in a separate process. Distinct funded default-strict transaction proofs
applied each call, spent one positive-fee Dust input, and returned
`IntentAlreadyExists` on replay with byte-identical ledger state. Changed IR,
checked Program and raw ZKIR refused before key generation. The over-cap
control observed a genuine k9 model. Corrupt proofs, a different verifier,
changed public binding and changed result at the same atom widths all
refused. The other exports retain model and native coverage.

### Standalone stateful Vector value qualification

Signed source `9d00dfd42` passed the standalone Ledger 9 gate on macOS arm64.
The 23 sources matched the independent and historical raw IR and the 23 new
Ledger 9 checked Program fixtures. The native gate passed 37 TypeScript/Rust
cases, 23 strict SDK checks, seven source refusals, seven malformed IR
refusals, and three changed-producer controls.

The two k7 exports used fresh ZKIR 3.2.0 keys. All three selected cases
passed separate standalone v3 verification and distinct funded default-strict
transaction proof/application with positive-fee Dust. Replay returned
`IntentAlreadyExists` with byte-identical ledger state. Changed IR,
changed or missing checked Programs, and changed ZKIR refused before
key generation. The genuine k9 refusal and corrupt-proof, wrong-verifier,
changed-binding and same-geometry changed-result controls passed. The
other exports retain model and native coverage.

### Standalone direct stateful Vector literal qualification

Signed source `23f214c75` passed the standalone macOS arm64 Ledger 9 gate.
The 31 original sources match the independent and historical raw IR. The
new fixture set retains all 34 exact Ledger 9 checked Programs separately
from the historical goldens. The native gate passed 50 TypeScript/Rust cases,
31 strict SDK checks, seven source refusals, seven malformed IR refusals, and
two changed-producer controls.

Fresh k7 keys from ZKIR 3.2.0 qualified the two selected direct-branch
exports. Both unsigned outcomes and the Field outcome produced fresh v3
standalone proofs that verified separately. Distinct funded default-strict
transaction proofs applied each call with positive-fee Dust. All three
replays returned `IntentAlreadyExists` with byte-identical ledger state.
The gate refused corrupted proofs, a different verifier, a changed
binding, and a changed same-width result. The changed/missing artifact
and genuine k9 controls refused before key generation. The other exports
retain model and native coverage.

### Standalone Fold Vector result qualification

Signed source `88863446d` passed the standalone macOS arm64 Ledger 9 gate.
All 18 sources matched independent and historical raw IR. The helper's
two current checked Programs have separate Ledger 9 goldens. The native
gate passed 33 cases and 18 strict SDK checks. Two of the 33 cases enforce
the pre-existing first-error ordering difference in the legacy named
Fold. TypeScript rejects the seed first and native rejects the items
first. Those two cases qualify the documented compatibility baseline.

Fresh ZKIR 3.2.0 k7 keys qualified `run` and `run_checked`. Each standalone
v3 proof verified separately. Each distinct funded default-strict
transaction proof applied with positive-fee Dust and returned
`IntentAlreadyExists` on replay with byte-identical ledger state.
The changed/missing artifact and genuine k9 controls refused before
key generation. The corrupt proof, wrong verifier, changed binding,
and same-width changed result controls also passed.

### Standalone Vector alias source qualification

Signed source `300284485` passed the standalone macOS arm64 Ledger 9 gate.
The 20 original sources matched independent and historical raw IR. The
native gate passed 26 TypeScript/Rust cases, 20 strict SDK checks, five
source refusals, three malformed IR refusals, and two changed-producer
controls. Both original helper exports used fresh k7 keys and produced
standalone v3 proofs that verified separately. Distinct funded default-strict
transaction proofs applied both calls with positive-fee Dust and rejected
replay with byte-identical ledger state. The changed/missing artifact,
corruption, binding, verifier, same-width result and genuine k9 controls
passed.

### Stateful Vector product elements qualification

The original `proof_candidate.run` and `checked_helper.run` model at k8 under
ZKIR 3.2.0. Both were k9 in the retained historical model expectations. The
current roster also observes the empty component moving from k5 to k6.

Signed source `1631ae2ad` passed 27 TypeScript/Rust cases, all 19 strict SDK
checks, and nine historical compiler scope controls on macOS arm64. The
checked helper's guard and narrowing refusals preserve their established
order. The original helper and checked helper both use complete unedited
generated SDKs at separate crate roots.

Four fresh k8 key pairs qualified five calls. The original helper and
Field cases passed, along with both original conditional Uint branches
and the valid checked-helper call. Each standalone proof verified
separately. A distinct funded default-strict transaction proof applied
each call with positive-fee Dust, and replay returned
`IntentAlreadyExists` with byte-identical ledger state. The gate refused
changed IR, Programs, raw ZKIR, a substituted same-k circuit, and a genuine
k9 model before key generation. Corrupted proof, wrong verifier, changed
binding, and same-width changed result controls passed.

### Standalone aggregate projection and struct member qualification

Both gates passed on macOS arm64 at signed `d66a9a4c9`. Aggregate projection
passed 21 original sources and strict SDK roots, 31 TypeScript/Rust cases,
four source refusals, five malformed IR refusals and two changed producers.
Struct member literals passed 18 original sources and strict SDK roots, 28
TypeScript/Rust cases, five source refusals, six malformed IR refusals and
two changed producers. Each source retained its historical raw IR and each
gate pins the released Ledger 9 Programs separately.

Both exports in each gate used fresh ZKIR 3.2.0 k7 keys. Four standalone v3
proofs verified separately, and four distinct funded default-strict
transaction proofs applied their calls with positive-fee Dust. Every replay
returned `IntentAlreadyExists` with byte-identical ledger state. Both gates
refused changed and missing artifacts, genuinely over-cap k9 models,
corrupted proofs, wrong verifiers, changed bindings and changed results
with the same atom widths.

### Integrated local qualification passed

The parent run at frozen source `78d8eaae4` completed the compiler,
workspace and registered consumer phases. It also completed the DID
lifecycle, digest-reducer and primitive-reducer gates. The DID relation
gate ran out of disk space while writing its receipt. All standalone
Vector migrations described above passed individually.

The maintained `local_parity_gate.py --full` passed on macOS arm64 with
Rust 1.99.0 at `9409b7da1cc652940469903a8380000b0b707239`. The run
used the Nix compiler and TypeScript 0.17.0 runtime from that revision.
It passed fixture generation and source refusals, workspace and
generated integration tests, backend Clippy, and the full generated
consumer proof gate. It checked 286 fixtures, bound 87 generated
consumers to their executed artifacts, and observed checked recording
for all 688 selected exports, including all 626 proof-eligible exports.

All nine child proof gates passed in the same run. Their 87 selected
calls cover DID lifecycle and reducer paths, AccJubjub, Vector
projection and constant-valued indexing, Map size expressions and
direct Fold. The readback verified that standalone and transaction
proofs differed, funded applications used default strictness, and
`IntentAlreadyExists` replay left serialized ledger state unchanged.
The standalone migration lanes described above retain their own 25
qualified cases at the recorded source revisions. Those counts describe
the selected calls, with overlaps across gates.

The full run used the earlier pinned native build of ZKIR 3.2.0. The
current Nix recipe adds Cargo's `--locked` flag and uses the same crate
archive and build inputs. The binaries have different hashes. A fresh
both-target Counter generation from the tested compiler matched the
retained Rust library and raw ZKIR. The new TypeScript capture matched
the independent Ledger 9 oracle and the native Rust test input,
including all four gas fields. The current packaged ZKIR reproduced the
independent Rust producer's binary IR and keys. A fresh standalone
proof verified in a separate process and refused wrong-key, binding,
commitment and corruption controls. A separately proved Dust-funded
transaction applied under default strictness and refused exact replay
without changing ledger bytes.

The local package audit verified 17 locked crate archives and 21
installed files from three pinned npm archives. Forty compiler-closure
and workflow controls passed. The compiler, Rust CLI, TypeScript runtime
and native ZKIR derivations evaluated for macOS arm64 and Linux x86_64.
The three required Linux product jobs also run the nine standalone
migration gates with the same compiler recipe, pinned TypeScript runtime
and native ZKIR. Each gate checks the emitted Rust library and raw ZKIR
roster before generating fresh keys. Native Linux execution of this
revision and distribution changes belong to integration.

Local evidence is retained under
`rust-ast-ledger9-migration-20261111` in
`workspace-ledger9-parent-parity-v5/full/receipt.json` and
`qualification-audit-v1/full-parent-readback.json`. The full receipt
SHA-256 is
`12ee47fd5280d03c3c708553034d0bd35976e0f682a0810f9cf4866d8b497746`.
The Ledger 8 branch, historical fixture and proof evidence, and the
deferred Forge branch were preserved.

For local iteration, reuse the exact Nix compiler and SDK closure and
warm Cargo build products first. In one retained 573-second outer-vector
gate, direct k7 and k8 key generation took 1.2 seconds. Three direct
Zerocash k13 and k15 runs took 3.47 to 6.97 seconds and reproduced the
retained artifacts byte for byte. The whole-CI share remains unknown.
Reconsider a Nix key bundle after measuring the actual affected gates.
Any bundle must bind the compiler recipe, fixture and import closure,
raw ZKIR, key tool and serialization version, platform and verified
parameter bytes. Run the full required test and proof gates after
compiler changes. Keep proof creation, verification, refusal and
replay checks fresh.
